package com.example.intentapps;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MoveActivityWithObjek extends AppCompatActivity {
    TextView Tvmoveactivitywithdata;
    Person orang = new Person();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_move_with_objek);
        Tvmoveactivitywithdata = findViewById(R.id.tvMoveActivityWithObjek);
        String Text = "Nama : " + orang.nama
                + "\nUmur : " + orang.Age
                + "\nJurusan : " + orang.Jurusan
                + "\nCita2 : " + orang.Cita;
        Tvmoveactivitywithdata.setText(Text);


    }
}
