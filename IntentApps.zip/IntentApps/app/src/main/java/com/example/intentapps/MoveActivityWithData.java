package com.example.intentapps;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MoveActivityWithData extends AppCompatActivity {
    public static final String Extra_Name = "A ";
    public static final String Extra_Age = " ";

    TextView TvResultActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_move_with_data);
        TvResultActivity = findViewById(R.id.data_received);
        String name = getIntent().getStringExtra(Extra_Name);
        int age = getIntent().getIntExtra(Extra_Age, 0);
        String text = "Nama : " + name + ",\n Umur : " + age;
        TvResultActivity.setText(text);
    }
}
