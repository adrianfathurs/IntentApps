package com.example.intentapps;

public class Person {
    public static String nama,Jurusan,Cita;
    public static int Age;


    public static void setNama(String name) {
        Person.nama = name;
    }

    public static String getNama() {
        return nama;
    }

    public static void setAge(int umur) {
        Person.Age=umur;
    }

    public static String getJurusan() {
        return Jurusan;
    }

    public static String getCita() {
        return Cita;
    }

    public static int getAge() {
        return Age;
    }

    public static void setJurusan(String jurusan)
    {
        Person.Jurusan=jurusan;
    }
    public static void setCita(String cita)
    {
        Person.Cita=cita;
    }




}
