package com.example.intentapps;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btnActivity, btnActivityData, btnToResult, btnDial,btnmoveactivitywithobjek;
    TextView TvResultActivty;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnActivity = findViewById(R.id.btnMove_Activity);
        btnActivityData = findViewById(R.id.btnMove_Activity_With_Data);
        btnToResult = findViewById(R.id.btnToResult);
        btnDial = findViewById(R.id.btnDialNumber);
        btnmoveactivitywithobjek = findViewById(R.id.btnMoveActivityObjekmain);
        TvResultActivty=findViewById(R.id.Resultactivity);
        btnActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, MoveActivity.class));
            }
        });
        btnActivityData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent move = new Intent(MainActivity.this, MoveActivityWithData.class);
                move.putExtra(MoveActivityWithData.Extra_Name, "Adrian_Fathur_Setyawan");
                move.putExtra(MoveActivityWithData.Extra_Age, 20);
                startActivity(move);
            }
        });
        btnDial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String PhoneNumber="087988";
                Intent DialPhoneNumber = new Intent(Intent.ACTION_DIAL, Uri.parse("tel: "+ PhoneNumber));
                startActivity(DialPhoneNumber);

            }
        });

        btnmoveactivitywithobjek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Person person = new Person();
                person.setNama("Adrian Fathur Setyawan");
                person.setAge(5);
                person.setJurusan("Informatic Enginnering");
                person.setCita("Android Developer");
                startActivity(new Intent(MainActivity.this, MoveActivityWithObjek.class));
            }
        });

    }
}
